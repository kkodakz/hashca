cat example.dict | ./hashcat -m 400 example400.hash
